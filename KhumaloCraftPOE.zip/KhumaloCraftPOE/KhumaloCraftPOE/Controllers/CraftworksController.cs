﻿using KhumaloCraftPOE.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace KhumaloCraftPOE.Controllers
{
    
    public class CraftworkController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AboutUs()
        {
            return View();
        }

        public IActionResult ContactUs()
        {
            return View();
        }
        

        public IActionResult MyWork()
        {
            var craftworks = new List<Craftwork>
    {
        new Craftwork
        {
            Name = "Enchanted Porcelain Vase",
            Description = "Delicately handcrafted porcelain vase adorned with intricate floral motifs, meticulously painted by skilled artisans. This elegant piece serves as a timeless centerpiece, adding a touch of sophistication to any space.",
            ImageURL1 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEhUQEBIVFRUVFRUVFRUVFRUVFRUVFRUWFhUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQFS0dHR0rLS0rKystLS0tKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKy0tKy0tLf/AABEIAPsAyQMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAAAQIEBQMGB//EADwQAAEDAgQCCAUDAgQHAAAAAAEAAhEDIQQSMUFRcQUiYYGRobHwBhMywdFCUuFy8WKCkrIHFBUWIyTC/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAECAwT/xAAiEQEBAAIBBAIDAQAAAAAAAAAAAQIRIQMSMUFRYRMiMiP/2gAMAwEAAhEDEQA/APSphRlMFbEgmkE0AE0IQCE0QgEIVbF42nSEvcAPvwQuUk3VkJrBd8U0dsx7h+U2fFFI/of4j8KuX58PluIWXT+IKDrdZvOPULQpVWuEggzp2qaax6uOV1KmhOEI6EhNJQCScIQJJSSQJCaSBIhCEEQmiEwqgCaSaBppJoGhJCBrxvSHSLfmVKVdge0PdAPMxfa2/avZLwHxE0DEVJsJnxhaxcevNxaFHAFsn5rOOVwIE/1AnzURhsFEirViY0Zr4LKZQdeWugEB0CQAVyxOHyHJNtnRYjVp4jZa1Hm/Hm26dPBgOcM7ssHrGAZ/phW+iOlPmV2U2DKwZrD+lxWHX6MLGhzHF8jrECBeLDiReVc+FR/7DCNIf45TqFmxvDp6ym3u0JIhZe0JpIQBSlMpQgcpIQoEhNJAJIKFQgpBRTRDTSTQCaSYQNCEIMb4vxdSjhKlSkSHNLLt1gvaHeRXyyp098yqC+XRBOYyXQRYntX2bGYVtWm+k8S17S13IiLdq+FdN9HPw2INKp9TXgAxZzSYBHYR5qFet/7yaZaKIDCQSC90RtYQLX2XoKNOjiaLqtMgmnOYb5YkGOET4L5YQQfcwreC6QfSBaxxFjcEgxMxI2Wts6evodJZGmlUd9JgxeWncRraCqvw9jzRxIcAXsl2kgkEESAdxMwvPUsUS6diu/RvS5o1vmRMW5oPtFGqHtD2mWuAIPEFThee+Dviui+m5tRtCm0OsX1AxxLzcNaYtqZleidUY4zTcHNgXBBE3BAI1gghc++d3a6a42SEIlbQkk0IEkU0IEEIhBUCQkmqEE1EJoiSYUU0DTUU0DTSQgF8/wDjDCMqONRwvTJcDykweywX0BxgTwXlMXhfm9UmzhE89VZOK49XLVj5jXGZ0gQqrrFaPS9B2GqvoP8A0m3Eg3aT3Qs6oZWdyzh2dG1dRuPNcqhvZJmy7Vg0NzO/umzR0sYaY2uYggGY/uF9P/4Z1w7D1L6VPp/bLQbHgTJjmvjNasXm9uA2C+lf8L+ladPNReYNVzcpi0tEBpO0yY/lSLt9MSSQtBykhCBlJCECQhCBFJNCCIKcqITRDUlEJoHKaSaATQhBwxboae4eax4gZpA6r4sCZiG2NvFaePMwPeoWJ09W+XQqnfI4A8M1hzP4W+3eFny82eX+s+ny7pwvNesTdznl224FrGJi2uyy6dUzBEK/jG5XmIF9AIHIcFTIzE+q4ya4eq3fLoDaYkdmqH4k1IYGiNo15rthsOTabKeCpfLcYb1tQSAfI2Vz4m2ZklgvhXE13BtFgJ1hzmt03uV9A+DPgU4Z4xGKcDUb9FNplrT+5x/UeA0HadMv4bxxbUZVI0deLCLhx8CV9OUx5m6soQhC2oSQhAIQkgEpTQgUoQhBEJpBMKoaYSTUAmhCBoKFF+nviqluoo4kkkxYidbDUb8lmfENBxpPYP10zlGhzC9+3RaxqNmTEhzgPGLLn0kWvbEwZ6p1gmwt3rvp4t87fHquAfUMgE2BtrpwUndDupVKbHjrOhxZqQCbTGmnmreMxGIw1V1FrhIsHFgJudRM/daHwv0c57zUqOdmcSS7c95Xn09dy4T/AOnN1iwIkaEWunU6NBsLuALmmPqA1bzXrMR0VIJHWMajquH2KxywgjK0FzTJOhEcQu0xmU089ysu2V0U0CW9oPef7ea+i9EVs9Fs6gZTzbae8Qe9eIxVHJUzN+l9/G/kV6boCtDi3Z4kcx/H+1ebHjePw7y8z7byITSK26hJNRQNJOUkCQhCBIQiUCCkAkmqhoQmoBCEIBHvwP8AATCeTbUxC3jOXLq5caRoYYAlwbczJ56hZdXCziAxujcrjJ9yt3N5KrTJNUmxAHC44me5bl5cNPGVujWVcVUcQD1y0f5RHqPNauAwTWEgNtNgdhJEie9VOi35nl54ud4k6+K3qTg5rTB7r7/yp6byvOnDKR9JDhteD+Cs3Fuk9YERe4MT3LYq0WgyQ4TMZZjnA0Pu6oYgOFwQ4X2g87DX3CsrFZOKw4fTc2btv3O4d90sDVLYv1gcw5haAfmMEXIc3xBOvMLNYMrjOgcPAjbwK55z95flqXh7HDVhUYHjcTHA7juNl1WN0HXgmmd+s3nFx4Ce4rZWXpxu5sihBSRo0kIKAQkhAFJNJAJqKYKqJIQE0AmkhQTYfBdWiSuDHkEyOEd8D7ru9jWlriTcxl/STGvhddZw8uV3Vd9QtmQ6BeSOH9lEUnEOIMSL7ECDp4jwU6js8AaEeW/qudZ0MqVA6SbbwLQQqnt5/oXChzXmYklo5yT9gtHANcwNaSLEgjfXiqmDeKbGA6uJcT2HS/vVX8NLutlkEQQbeE62Pkp6MucltgmWHu+0FUMbRj6hv9bYHKf5srbnFpFjpHfa3bv5p1KrXDK7exB1uoMksyw4GQIJJ1sZtAWbVZFR4jYergFu1MG2MgsYOllkYoH5s8Wg+JH5Wc/V+4RGi8tIcP0wROsdvvcr09CqHtDhofZC8s2prxBMjSeXBy0uhsQA405s7rM+/kPJXOc7dOll6baRSlKVh6DQUAoQJCChAIQkgiE1FNVEpTlQTlBOVF74SVbF1IIHvf8ACsZz8LHz4cBeIBPZrHJdXYnNVAH0tBLj229+Ko55aTfrdWQNdvDU965Nqta95MkHKLze0xylbjzVapYsZzaLwI2A9NVV+IKzg3LT1cQSBwJgkcdlnur9YsvIAvqczrkcrFdalRzwBA6oIm09oI2VsTGr7WNqNy8ABaLRou4cWESZEQDpfQArOw1RwmwlsTlIuOPbeV3GJnqvEcZ0NksJWiWB4g9x3HaFya7Vp1Bg7d4XPB1bRtqJ4FPFgOEgwRuNbeoWWlavTeHGDA2m/Hh3fztmV3dZhP8AiHgTZaFeuJAJHfwjhzWRXOw0BdHItkLPV/ipPMSqGKjg4Wdy1Gnvkq/zhTexzdAQ4ctx3/lWca8GOPsfdUajIBnh3jf7rWXMXF7SULhgnzTYTuxvoF2JXN6kkKIQSimUJIQNCUpojmEwVEJyqHKajKJQSWdj3/8AkZyJV+VkdNGHsf2OHkVYzn4WTXyt5NHoqdYEw2YOUuM7WmJ7wuD8RmbU5x3ZQo4l9nnfJl/1OAA8luPPUcOTBJE5iTPHKSIHcFoAtAJbqW6jSbXPG5WeW5W07EQL8r6cdV3NaC4AWaIsOInu0Vt2zIjRrXNyAeIH6T273PgFcr9ZmtxwE8RoOwqriKTRTAiYIAO8GAQutA5HF0mNIsBPZ73UtXSUmnABzTGg00BAjuKlSrODi08NyDc6ack8h6pB0JmeW0e7rgypD3E8YJ7ABHqVNrpE1A5r5+ptgf6gstriWidZPiGn8K9TsKgI/UI7gFnfMsBv1yf9J/Kz1b+lJOYtVes3SeEagx2KJdJMbxPKL+YXT5gFv8P2C5YJoe8Ab5R63V9NYR6nBtimwcGN9AusqIKcrD0pSiVGU5REpQoolA5TlRSlBFEpIVDlJIoQOVQ6Zp5mTwPrb8K6SudduZpbxCF8POYeoIcTxa6P8rVNsZ3d3KxP8LkwluYREGf4U6b7vtvJ57fdalcLHes/rMdqAAPvdc6LzNRp/UYHaBM35IGgJtxm/G3JRZXDQQ7UE87gCyu2dO1Wocga4E/SSYtqDdW6L4JHAAd2yq1HwwRMkNi/KyTagIzGx92U2aaFGocpns85396Kv83rDlx0lRFXqcyuBeASOIJRdI1TAeSNyQZ4gD8rOBk5RtDR4yf9pV5j4Bkz1p4aQY8AsmnV3bqSQOZsffasZ86xJ5W8Q4ZiDoAPHgr/AEBTl5ds0W5wB+VjVAXOJ7fsN16PoKllpz+4z3bfdareEbAKcrkHKUqOyYKaiFIIGE0kKIlKFGEIIIlEoVCQUigoqJKg4qZK5OKqMnHUwHk/uHnuq7NxxAPeFpY6nmb2i4WU03HbI8Uc8obhIA5eqi1wBJAHhpFvsoB9x2SI7wfuk14G0X8rowlUeSGmOG+2x98Vy+b1HX3AEc+1METkv9APgbKlVbLeyQfP1uqNP5pDWzufZ8VWxeJIDnDaB47qL3yGjW0kcQT6rnWMMd2k+igK9cmnbUi3fb0VenTy/LHAEnt3nyXSqdByHgP4XKs+SeWWeCzOch3otLnBv7iPMXXraQAAA0AheKpYg0yCDf377ltYPpn947wndHbGcPQtK6NKq4bENfoVaaq0mFMFRAUkRKUJJqAQhNBzQlKkqqMJEKcJEIjkQoOC75VEtQUsQcokrzhxAdJGxNuRlb3S4OQryj2lhzDTf8qWpZuLtV+/Az3EQffYovfrrqLc1GnUEROxA4cR5IyzE6xsq5INs8HiCPEzC5un5flHbNj6KcXEcftp5KNUQOenvwVAKnXg6hjfuVHEPnK2NXHwXB9Mue4zBkX12g+qnXaW34dUHaTughUfJ10n35FL5nv1/CTWjTb3/HiuTGlxgcieH8rGPjZjEqcuMq7Spp4fDQrjKSy9AoSLhegwGJkQVjMYrNBxaUl0V6GFIBV8JVkXVkBbZEIhNNBFCkkg4qSipBUNNARKBFOEwmEFfE0Q4QvO4nBZTEL1RC4YjDBylm1eOqdH7tJadbaHmFD/AJeq3YO5GD4H8rfr4It7Qq+VZ8FkrF+W6B1HAzNhMHuUBUgjM1+2jHfi63cqcK9zP4480ym7MSGP1JHUPG2sKdXCVXwAyBM9Zw/+ZXoMqRap3HZGMzosn63E9g6o/JV2nhABAEK7lRlUbk04CiugYuicIIZV3w9OSuYCs0nQitLDtAC7qlSqq0xy2ymE5USUIHKJSSQQUmlRTVEggJKQKIJUgkhAyhIFNAiJ1XCphGuVgoQZlTo07FcHYN42WymFnti7YJw7uCiaJ4Lfhc3tHBO02wsh4JLTq01Sq0oWbFcQiU0lFNOUgFNoQdablcouXCkxW6bFuI7sKaTRCaqBOEkkHMFSCi1SVDhSAUUwUQwmkmEDhCEIAoCCkEDCCmkgFEhSCagruYuFWkrjkiEVlvw65GgVqEKJas6VmigV2p0FcaFIBNDkymu7E2hShaDlCSaIEoQmg//Z",
            Price = 950.00m
        },
        new Craftwork
        {
            Name = "Artisanal Rattan Basket",
            Description = "A masterfully woven rattan basket, expertly crafted using traditional techniques passed down through generations. Each intricate weave showcases the artisan's meticulous attention to detail, making this piece both functional and a work of art.",
            ImageURL1 = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQM7MQCqhJXpZJC8oDa7owxC0-UuMRtLD6PHLJXnDAmeA&s",
            Price = 650.00m
        },
        new Craftwork
        {
            Name = "Heritage Wooden Tray",
            Description = "Exquisite hand-carved wooden tray featuring intricate geometric patterns inspired by ancient African motifs. Crafted from sustainably sourced wood, this unique serving tray adds a touch of cultural richness to your dining experience.",
            ImageURL1 = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXpj5Y0ukWq0bnHWEFXzB7V9aPz0jFA0PQGA&s",
            Price = 1150.00m
        }
    };

            return View(craftworks);
        }

    }
}