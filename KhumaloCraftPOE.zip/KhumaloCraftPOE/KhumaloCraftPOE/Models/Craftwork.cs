﻿namespace KhumaloCraftPOE.Models
{

   
    public class Craftwork
    {
        public int CraftworkId { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? ImageURL1 { get; set; }
        public string? ImageURL2 { get; set; }
        public string? ImageURL3 { get; set; }
        public decimal Price { get; set; }
    }
}